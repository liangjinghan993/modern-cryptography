def f(x, y, mod):
    a = 0
    m = 1
    if y == 1:
        return 0
    a += 1
    while (m * x) % mod != y:
        a += 1
        m = (m * x) % mod
    return a

def power(x, e, n):
    m = 1
    while e > 0:
        if e & 1:
            m = (m * x) % n
        x = (x * x) % n
        e >>= 1
    return m

def modx(x, y, mod):
    while x < 0 or y < 0:
        x += mod
        y += mod
    x %= mod
    y %= mod
    sum_val = 0
    while x != 0:
        if x & 1:
            sum_val += y
            sum_val %= mod
        y = y << 1
        x = x >> 1
    return sum_val

def modj(x, y, mod):
    z = x - y
    while z < 0:
        z += mod
    return z % mod

def calculate_A(p, m, y, a):
    z = [[0] * (m + 2) for _ in range(m + 3)]
    for i in range(1, m + 2):
        z[i][0] = 1
        for j in range(1, m + 1):
            z[i][j] = 0

    for j in range(1, m + 2):
        c = 0  # 记录z[j][]的最高次数
        for h in range(1, m + 2):
            k = modj(y[j], y[h], p)
            k = power(k, p - 2, p)  # k=1/k mod p
            t = modx(-y[h], k, p)

            if h != j:
                for i in range(c, -1, -1):
                    z[j][i + 1] = modx(z[j][i], k, p) + modx(z[j][i + 1], t, p)
                    z[j][i + 1] %= p
                z[j][0] = modx(z[j][0], t, p)
                c += 1

    A = [[0] * (m + 2) for _ in range(m + 2)]  # 存储Π(y-yh)/(yj-yh)的值
    for i in range(m + 2):
        for j in range(m + 2):
            A[i][j] = 0

    for j in range(1, m + 2):
        for i in range(m + 1):  # x^i
            for h in range(m + 1):  # y^h
                A[i][h] += modx(a[j][i], z[j][h], p)
                A[i][h] %= p

    return A

if __name__ == "__main__":
    p, m = map(int, input().split())
    y = [0] * (m + 3)
    a = [[0] * (m + 2) for _ in range(m + 3)]
    for i in range(1, m + 2):
        a[i] = [0] * (m + 2)

    y[1:m + 2] = map(int, input().split())

    for i in range(1, m + 2):
        a[i] = list(map(int, input().split()))

    A = calculate_A(p, m, y, a)

    for i in range(m + 1):
        for j in range(m + 1):
            print(A[i][j], end=" ")
            if j == m:
                print()